//Johnny Canal Segura
//04/14/2023


#include <iostream>
#include <fstream>
#include <map>

using namespace std;

//Create class to track Grocery items 
class Grocer {
private:
	map<string, int> items;

public:
	//Open capability to read outside file
	void readFile(string fileName) {
		ifstream inputFile;
		inputFile.open(fileName);
		//Read only open files
		if (inputFile.is_open()) {
			string item;
			//Loop through items within "inputFile" list
			while (inputFile >> item) {
				//Add to total of given item found in list
				items[item]++;
			}
			//Close file no longer allow read or write
			inputFile.close();
		}
		else {
			//Prompt user to enter valid file
			cout << "Unable to open file" << endl;
		}
	}void writeFile(string fileName) {
		ofstream outputFile;
		outputFile.open(fileName);
		//Add results to output file to display results to user
		if (outputFile.is_open()) {
			for (auto const& item : items) {
				outputFile << item.first << " " << item.second << endl;
			}
			//Close output file no longer allow read or write
			outputFile.close();
		}
		//Prompt user to enter valid file name
		else {
			cout << "Unable to open file" << endl;
		}
	}int findItem(string item) {
		if (items.count(item) > 0) {
			return items[item];
		}
		else {
			return 0;
		}
	}
	//Calculate frequency of each item
	void printFrequency() {
		for (auto const& item : items) {
			cout << item.first << " " << item.second << endl;
		}
	}
	//Add * to each number of instances for each item
	void printHistogram() {
		for (auto const& item : items) {
			cout << item.first << " ";
			for (int i = 0; i < item.second; i++) {
				cout << "*";
			}
			cout << endl;
		}
	}
};

int main() {
	Grocer grocer;
	//allow for reading of item list file
	grocer.readFile("CS210_Project_Three_Input_File.txt");
	//Allow for writing results to frequency data file
	grocer.writeFile("frequency.dat");

	int choice;
	string item;
	do {
		//Output list of available options to user
		cout << "1. Find item frequency" << endl;
		cout << "2. Print frequency of all items" << endl;
		cout << "3. Print histogram of all items" << endl;
		cout << "4. Exit" << endl;
		cout << "Enter your choice: " << endl;
		cin >> choice;
		//Output item frequency, all items frequency, histogram for each item, or invalid choice based on user selection
		switch (choice) {
		case 1:
			cout << "Enter item: ";
			cin >> item;
			cout << "Frequency: " << grocer.findItem(item) << endl;
			break;
		case 2:
			grocer.printFrequency();
			break;
		case 3:
			grocer.printHistogram();
			break;
		case 4:
			break;
		default:
			cout << "Invalid choice" << endl;
			break;
		}
	//Exit if user enters option 4
	} while (choice != 4);

	return 0;

	}